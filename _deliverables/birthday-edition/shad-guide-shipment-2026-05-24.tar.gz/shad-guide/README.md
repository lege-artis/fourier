# Just Shad's Guide to Fourier's Galaxy — v0.2.x-opus-iter (2026-05-24)

Self-contained LaTeX shipment. To build:

```
./build.sh
```

Or open `shad-guide.tex` in any LaTeX editor (Overleaf / TeXShop /
TeXstudio / VS Code + LaTeX Workshop) and hit Build.

Required TeX Live packages (BasicTeX users will need to install most
of these via `tlmgr install`):
  titlesec tcolorbox enumitem csquotes pgf environ etoolbox
  trimspaces tikzfill pdfcol listingsutf8 bigfoot currfile multirow
  collection-fontsrecommended

Bundle contents:
  shad-guide.tex        single-file LaTeX source
  build.sh              pdflatex two-pass build script
  figures/              ~50 PNGs (dragons + spectrum / component plots)
  data/                 4 real-data head fixtures inlined via \lstinputlisting
  README.md             this file

This iteration carries voice-pass v0.2 (Hitchhiker's Guide style) on
the Preamble & Dedication chapter and on the B1 oscilloscope band.
B2-B5 carry the v0.2.x-first-cut content; voice-pass on those is
scheduled for v0.2.x-sonnet-batch.

Source data, licensing, and reproduction trail are in Appendix A of
the rendered PDF.

 Pete Y.
