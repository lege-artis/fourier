#!/usr/bin/env bash
# Build shad-guide.pdf from this shipment.
# Two pdflatex passes resolve TOC + cross-references.
set -euo pipefail
cd "$(dirname "$0")"
pdflatex -interaction=nonstopmode -halt-on-error shad-guide.tex
pdflatex -interaction=nonstopmode -halt-on-error shad-guide.tex
echo "  built  ->  $(pwd)/shad-guide.pdf"
